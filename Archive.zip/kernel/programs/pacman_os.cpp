#include <algorithm>
#include <cstdint>

#include <oslib/keyboard.h>
#include <kernel/drivers/tsc_deadline.h>
#include <oslib/win.h>
#include <kernel/scheduler.h>

extern "C" {
void pacman_game_init(void);
void pacman_game_frame(uint32_t frame_time_ns);
void pacman_game_input(bool up, bool down, bool left, bool right, bool escape,
                       bool anykey);
void pacman_game_shutdown(void);

bool pacman_os_present(const uint32_t *pixels, uint32_t width, uint32_t height);
}

namespace Kernel::Games::Pacman {
namespace {
constexpr uint32_t kGameWidth = 224;
constexpr uint32_t kGameHeight = 288;
constexpr uint32_t kWindowWidth = 448;
constexpr uint32_t kWindowHeight = 576;

alignas(64) uint32_t
    g_window_pixels[static_cast<size_t>(kWindowWidth) * kWindowHeight];
oslib::Win window;

bool key_down(uint8_t scancode, bool extended = false) {
  return extended ? oslib::Keyboard::is_extended_pressed(scancode)
                  : oslib::Keyboard::is_pressed(scancode);
}

} // namespace

extern "C" bool pacman_os_present(const uint32_t *pixels, uint32_t width,
                                  uint32_t height) {
  if (!pixels || width != kGameWidth || height != kGameHeight ||
      !window.valid())
    return false;

  const uint32_t target_width = window.width();
  const uint32_t target_height = window.height();
  uint32_t *target = window.pixels();
  if (!target || target_width == 0 || target_height == 0)
    return false;

  for (uint32_t y = 0; y < target_height; ++y) {
    const uint32_t source_y = static_cast<uint32_t>(static_cast<uint64_t>(y) *
                                                    height / target_height);
    for (uint32_t x = 0; x < target_width; ++x) {
      const uint32_t source_x = static_cast<uint32_t>(static_cast<uint64_t>(x) *
                                                      width / target_width);
      target[static_cast<size_t>(y) * target_width + x] =
          pixels[static_cast<size_t>(source_y) * width + source_x];
    }
  }

  return window.present_pixels(target, target_width, target_height,
                               target_width * sizeof(uint32_t));
}

void run() {
  if (!window.open(kWindowWidth, kWindowHeight))
    return;

  const uint32_t w = window.width();
  const uint32_t h = window.height();
  const size_t needed_pixels = static_cast<size_t>(w) * h;
  if (w == 0 || h == 0 ||
      needed_pixels > sizeof(g_window_pixels) / sizeof(g_window_pixels[0]) ||
      !window.attach_pixels(g_window_pixels, 0, 0, w, h)) {
    window.unregister();
    window.close();
    return;
  }

  pacman_game_init();
  uint32_t last_tick = Kernel::Drivers::TSCDeadline::get_ticks();

  while (!Kernel::Scheduler::should_stop() && window.exists()) {
    const uint32_t current_tick = Kernel::Drivers::TSCDeadline::get_ticks();
    const uint64_t delta_ns =
        static_cast<uint64_t>(current_tick - last_tick) * 1000000ULL;
    last_tick = current_tick;

    const bool focused = window.has_focus();
    const bool up = focused && (key_down(0x48, true) || key_down(0x11));
    const bool down = focused && (key_down(0x50, true) || key_down(0x1F));
    const bool left = focused && (key_down(0x4B, true) || key_down(0x1E));
    const bool right = focused && (key_down(0x4D, true) || key_down(0x20));
    const bool escape = focused && key_down(0x01);
    const bool anykey = focused && (up || down || left || right || escape ||
                                    key_down(0x39) || key_down(0x1C));
    if (escape)
      break;

    pacman_game_input(up, down, left, right, false, anykey);

    const uint32_t frame_time_ns =
        static_cast<uint32_t>(std::min<uint64_t>(delta_ns, UINT32_MAX));
    pacman_game_frame(frame_time_ns);
    Kernel::Scheduler::thread_sleep_ms(2);
  }

  pacman_game_shutdown();
  window.unregister();
  window.close();
}
} // namespace Kernel::Games::Pacman
