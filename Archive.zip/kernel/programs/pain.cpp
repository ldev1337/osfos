#include <stdlib.h>
#include <string.h>
#include <kernel/fs/laziofs.h>
#include <oslib/win.h>
#include <oslib/ui.h>
#include <kernel/scheduler.h>

#include <utility>


namespace Kernel::Apps::Pain {

enum class Tool {
  Pencil,
  Eraser,
  Line,
  Rect,
  FillRect,
  Circle,
  FillCircle,
  FloodFill,
  Eyedropper
};

inline auto calculate_crc32(const uint8_t *data, size_t length) -> uint32_t {
  uint32_t crc = 0xFFFFFFFF;
  for (size_t i = 0; i < length; ++i) {
    crc ^= data[i];
    for (int j = 0; j < 8; ++j)
      crc = (crc & 1) ? (crc >> 1) ^ 0xEDB88320 : (crc >> 1);
  }
  return ~crc;
}

inline auto calculate_adler32(const uint8_t *data, size_t length) -> uint32_t {
  uint32_t s1 = 1, s2 = 0;
  for (size_t i = 0; i < length; ++i) {
    s1 = (s1 + data[i]) % 65521;
    s2 = (s2 + s1) % 65521;
  }
  return (s2 << 16) | s1;
}

inline auto save_png(const char *filename, const uint32_t *pixels,
                     uint32_t width, uint32_t height) -> bool {
  void *f = Kernel::FS::VFS::vfs_open(filename, "w+");
  if (!f)
    return false;

  const uint8_t png_sig[8] = {137, 80, 78, 71, 13, 10, 26, 10};
  Kernel::FS::VFS::vfs_write(png_sig, 1, 8, f);

  uint8_t ihdr_data[13] = {static_cast<uint8_t>(width >> 24),
                           static_cast<uint8_t>(width >> 16),
                           static_cast<uint8_t>(width >> 8),
                           static_cast<uint8_t>(width),
                           static_cast<uint8_t>(height >> 24),
                           static_cast<uint8_t>(height >> 16),
                           static_cast<uint8_t>(height >> 8),
                           static_cast<uint8_t>(height),
                           8,
                           6,
                           0,
                           0,
                           0};

  uint32_t net_len = __builtin_bswap32(13);
  uint8_t ihdr_type[4] = {'I', 'H', 'D', 'R'};
  Kernel::FS::VFS::vfs_write(&net_len, 1, 4, f);
  Kernel::FS::VFS::vfs_write(ihdr_type, 1, 4, f);
  Kernel::FS::VFS::vfs_write(ihdr_data, 1, 13, f);

  uint8_t crc_buf[17];
  memcpy(crc_buf, ihdr_type, 4);
  memcpy(crc_buf + 4, ihdr_data, 13);
  uint32_t crc = __builtin_bswap32(calculate_crc32(crc_buf, 17));
  Kernel::FS::VFS::vfs_write(&crc, 1, 4, f);

  size_t row_size = width * 4 + 1;
  size_t total_idat_data = height * row_size;
  uint8_t *raw_filtered = static_cast<uint8_t *>(malloc(total_idat_data));
  size_t raw_offset = 0;

  for (uint32_t y = 0; y < height; ++y) {
    raw_filtered[raw_offset++] = 0;
    for (uint32_t x = 0; x < width; ++x) {
      uint32_t p = pixels[y * width + x];
      raw_filtered[raw_offset++] = (p >> 16) & 0xFF;
      raw_filtered[raw_offset++] = (p >> 8) & 0xFF;
      raw_filtered[raw_offset++] = p & 0xFF;
      raw_filtered[raw_offset++] = (p >> 24) & 0xFF;
    }
  }

  size_t num_blocks = (total_idat_data + 65534) / 65535;
  size_t zlib_size = 2 + total_idat_data + (num_blocks * 5) + 4;
  uint8_t *zlib_buf = static_cast<uint8_t *>(malloc(zlib_size));
  size_t z_idx = 0;
  zlib_buf[z_idx++] = 0x78;
  zlib_buf[z_idx++] = 0x01;

  size_t remaining = total_idat_data;
  size_t src_offset = 0;
  while (remaining > 0) {
    size_t block_len = remaining > 65535 ? 65535 : remaining;
    remaining -= block_len;
    bool final = (remaining == 0);

    zlib_buf[z_idx++] = final ? 0x01 : 0x00;
    zlib_buf[z_idx++] = block_len & 0xFF;
    zlib_buf[z_idx++] = (block_len >> 8) & 0xFF;
    uint16_t nl = ~(static_cast<uint16_t>(block_len));
    zlib_buf[z_idx++] = nl & 0xFF;
    zlib_buf[z_idx++] = (nl >> 8) & 0xFF;

    memcpy(zlib_buf + z_idx, raw_filtered + src_offset, block_len);
    z_idx += block_len;
    src_offset += block_len;
  }
  free(raw_filtered);

  uint32_t adler = calculate_adler32(zlib_buf + 2, z_idx - 2);
  zlib_buf[z_idx++] = (adler >> 24) & 0xFF;
  zlib_buf[z_idx++] = (adler >> 16) & 0xFF;
  zlib_buf[z_idx++] = (adler >> 8) & 0xFF;
  zlib_buf[z_idx++] = adler & 0xFF;

  uint32_t net_idat_len = __builtin_bswap32(z_idx);
  uint8_t idat_type[4] = {'I', 'D', 'A', 'T'};
  Kernel::FS::VFS::vfs_write(&net_idat_len, 1, 4, f);
  Kernel::FS::VFS::vfs_write(idat_type, 1, 4, f);
  Kernel::FS::VFS::vfs_write(zlib_buf, 1, z_idx, f);

  uint8_t *idat_crc_buf = static_cast<uint8_t *>(malloc(4 + z_idx));
  memcpy(idat_crc_buf, idat_type, 4);
  memcpy(idat_crc_buf + 4, zlib_buf, z_idx);
  uint32_t idat_crc =
      __builtin_bswap32(calculate_crc32(idat_crc_buf, 4 + z_idx));
  Kernel::FS::VFS::vfs_write(&idat_crc, 1, 4, f);
  free(idat_crc_buf);
  free(zlib_buf);

  uint32_t zero_len = 0;
  uint8_t iend_type[4] = {'I', 'E', 'N', 'D'};
  Kernel::FS::VFS::vfs_write(&zero_len, 1, 4, f);
  Kernel::FS::VFS::vfs_write(iend_type, 1, 4, f);
  uint32_t iend_crc = __builtin_bswap32(0xAE426082);
  Kernel::FS::VFS::vfs_write(&iend_crc, 1, 4, f);

  Kernel::FS::VFS::vfs_close(f);
  return true;
}

inline auto load_png(const char *filename, uint32_t *pixels, uint32_t width,
                     uint32_t height) -> bool {
  void *f = Kernel::FS::VFS::vfs_open(filename, "r");
  if (!f)
    return false;

  size_t filesize = Kernel::FS::VFS::vfs_size(f);
  if (filesize < 33) {
    Kernel::FS::VFS::vfs_close(f);
    return false;
  }

  uint8_t *file_data = static_cast<uint8_t *>(malloc(filesize));
  Kernel::FS::VFS::vfs_read(file_data, 1, filesize, f);
  Kernel::FS::VFS::vfs_close(f);

  const uint8_t png_sig[8] = {137, 80, 78, 71, 13, 10, 26, 10};
  if (memcmp(file_data, png_sig, 8) != 0) {
    free(file_data);
    return false;
  }

  size_t offset = 8;
  bool success = false;

  while (offset < filesize) {
    uint32_t chunk_len =
        __builtin_bswap32(*reinterpret_cast<uint32_t *>(file_data + offset));
    offset += 4;
    char chunk_type[5];
    memcpy(chunk_type, file_data + offset, 4);
    chunk_type[4] = '\0';
    offset += 4;

    if (strcmp(chunk_type, "IDAT") == 0) {
      const uint8_t *zdata = file_data + offset;
      size_t z_pos = 2;
      size_t z_end = chunk_len;
      size_t row_size = width * 4 + 1;
      auto *raw_filtered = static_cast<uint8_t *>(malloc(height * row_size));
      size_t raw_pos = 0;

      while (z_pos < z_end - 4) {
        uint8_t hdr = zdata[z_pos++];
        uint16_t block_len = zdata[z_pos] | (zdata[z_pos + 1] << 8);
        z_pos += 4;
        memcpy(raw_filtered + raw_pos, zdata + z_pos, block_len);
        raw_pos += block_len;
        z_pos += block_len;
        if ((hdr & 1) != 0)
          break;
      }

      size_t rf_idx = 0;
      for (uint32_t y = 0; y < height; ++y) {
        rf_idx++;
        for (uint32_t x = 0; x < width; ++x) {
          uint8_t r = raw_filtered[rf_idx++];
          uint8_t g = raw_filtered[rf_idx++];
          uint8_t b = raw_filtered[rf_idx++];
          uint8_t a = raw_filtered[rf_idx++];
          pixels[(y * width) + x] = (static_cast<uint32_t>(a) << 24) |
                                    (static_cast<uint32_t>(r) << 16) |
                                    (static_cast<uint32_t>(g) << 8) |
                                    static_cast<uint32_t>(b);
        }
      }
      free(raw_filtered);
      success = true;
    } else if (strcmp(chunk_type, "IEND") == 0) {
      break;
    }
    offset += chunk_len + 4;
  }

  free(file_data);
  return success;
}

inline void draw_line_pixels(uint32_t *canvas, uint32_t cw, uint32_t ch, int x0,
                             int y0, int x1, int y1, uint32_t color,
                             int width = 1) {
  int dx = __builtin_abs(x1 - x0);
  int dy = __builtin_abs(y1 - y0);
  int sx = (x0 < x1) ? 1 : -1;
  int sy = (y0 < y1) ? 1 : -1;
  int err = dx - dy;

  while (true) {
    for (int wy = -width / 2; wy <= width / 2; ++wy) {
      for (int wx = -width / 2; wx <= width / 2; ++wx) {
        int px = x0 + wx;
        int py = y0 + wy;
        if (px >= 0 && px < static_cast<int>(cw) && py >= 0 &&
            py < static_cast<int>(ch)) {
          canvas[py * cw + px] = color;
        }
      }
    }
    if (x0 == x1 && y0 == y1)
      break;
    int e2 = 2 * err;
    if (e2 > -dy) {
      err -= dy;
      x0 += sx;
    }
    if (e2 < dx) {
      err += dx;
      y0 += sy;
    }
  }
}

inline void draw_rect_pixels(uint32_t *canvas, uint32_t cw, uint32_t ch, int x0,
                             int y0, int x1, int y1, uint32_t color,
                             bool filled, int width = 1) {
  int min_x = x0 < x1 ? x0 : x1;
  int max_x = x0 > x1 ? x0 : x1;
  int min_y = y0 < y1 ? y0 : y1;
  int max_y = y0 > y1 ? y0 : y1;

  for (int y = min_y; y <= max_y; ++y) {
    for (int x = min_x; x <= max_x; ++x) {
      if (x >= 0 && x < static_cast<int>(cw) && y >= 0 &&
          y < static_cast<int>(ch)) {
        if (filled || x < min_x + width || x > max_x - width ||
            y < min_y + width || y > max_y - width) {
          canvas[y * cw + x] = color;
        }
      }
    }
  }
}

inline void draw_circle_pixels(uint32_t *canvas, uint32_t cw, uint32_t ch,
                               int xc, int yc, int r, uint32_t color,
                               bool filled, int width = 1) {
  if (r < 0)
    r = -r;
  int x = 0;
  int y = r;
  int d = 3 - 2 * r;

  auto plot_symmetric = [&](int cx, int cy, int px, int py) {
    int points[8][2] = {{cx + px, cy + py}, {cx - px, cy + py},
                        {cx + px, cy - py}, {cx - px, cy - py},
                        {cx + py, cy + px}, {cx - py, cy + px},
                        {cx + py, cy - px}, {cx - py, cy - px}};
    for (auto &pt : points) {
      for (int wy = -width / 2; wy <= width / 2; ++wy) {
        for (int wx = -width / 2; wx <= width / 2; ++wx) {
          int fx = pt[0] + wx;
          int fy = pt[1] + wy;
          if (fx >= 0 && fx < static_cast<int>(cw) && fy >= 0 &&
              fy < static_cast<int>(ch)) {
            canvas[fy * cw + fx] = color;
          }
        }
      }
    }
  };

  while (y >= x) {
    if (filled) {
      draw_line_pixels(canvas, cw, ch, xc - x, yc + y, xc + x, yc + y, color,
                       1);
      draw_line_pixels(canvas, cw, ch, xc - x, yc - y, xc + x, yc - y, color,
                       1);
      draw_line_pixels(canvas, cw, ch, xc - y, yc + x, xc + y, yc + x, color,
                       1);
      draw_line_pixels(canvas, cw, ch, xc - y, yc - x, xc + y, yc - x, color,
                       1);
    } else {
      plot_symmetric(xc, yc, x, y);
    }
    x++;
    if (d > 0) {
      y--;
      d = d + 4 * (x - y) + 10;
    } else {
      d = d + 4 * x + 6;
    }
  }
}

inline void flood_fill(uint32_t *canvas, uint32_t cw, uint32_t ch, int start_x,
                       int start_y, uint32_t new_color) {
  if (start_x < 0 || std::cmp_greater_equal(start_x, cw) || start_y < 0 ||
      std::cmp_greater_equal(start_y, ch))
    return;
  uint32_t target_color = canvas[start_y * cw + start_x];
  if (target_color == new_color)
    return;

  struct Point {
    int x, y;
  };
  size_t stack_capacity = cw * ch;
  Point *stack = static_cast<Point *>(malloc(stack_capacity * sizeof(Point)));
  size_t top = 0;

  stack[top++] = {.x = start_x, .y = start_y};

  while (top > 0) {
    Point p = stack[--top];
    int x = p.x;
    int y = p.y;

    if (x < 0 || x >= static_cast<int>(cw) || y < 0 ||
        y >= static_cast<int>(ch))
      continue;
    if (canvas[y * cw + x] != target_color)
      continue;

    canvas[y * cw + x] = new_color;

    if (top + 4 < stack_capacity) {
      stack[top++] = {.x = x + 1, .y = y};
      stack[top++] = {.x = x - 1, .y = y};
      stack[top++] = {.x = x, .y = y + 1};
      stack[top++] = {.x = x, .y = y - 1};
    }
  }
  free(stack);
}

void run() {
  oslib::Win win;
  if (!win.open(1024, 720))
    return;
  const auto sw = static_cast<int32_t>(win.width());
  const auto sh = static_cast<int32_t>(win.height());
  const uint32_t canvas_w = sw;
  const uint32_t canvas_h = sh > 120 ? sh - 120 : sh;

  const uint32_t COLOR_BG = 0xFF1E1E2E;
  const uint32_t COLOR_CANVAS = 0xFFFFFFFF;
  const uint32_t COLOR_TEXT = 0xFFCDD6F4;

  uint32_t *canvas =
      static_cast<uint32_t *>(malloc(canvas_w * canvas_h * sizeof(uint32_t)));
  uint32_t *backup_canvas =
      static_cast<uint32_t *>(malloc(canvas_w * canvas_h * sizeof(uint32_t)));
  if ((canvas == nullptr) || (backup_canvas == nullptr))
    return;
  for (size_t i = 0; i < canvas_w * canvas_h; ++i)
    canvas[i] = COLOR_CANVAS;
  memcpy(backup_canvas, canvas, canvas_w * canvas_h * sizeof(uint32_t));

  Tool current_tool = Tool::Pencil;
  int cur_r = 0;
  int cur_g = 0;
  int cur_b = 0;
  char status_msg[64] = "Ready. Use widgets & RGB sliders to paint.";

  bool mouse_down_prev = false;
  int start_x = -1, start_y = -1;
  bool dragging = false;

  // --- Instantiate UI Widgets in Panel ---
  // Tool buttons (Row 1: y = canvas_h + 8)
  UI::Button btn_pencil(10, canvas_h + 8, 55, 24, "Pencil");
  UI::Button btn_eraser(70, canvas_h + 8, 55, 24, "Eraser");
  UI::Button btn_line(130, canvas_h + 8, 50, 24, "Line");
  UI::Button btn_rect(185, canvas_h + 8, 55, 24, "Rect");
  UI::Button btn_fillrect(245, canvas_h + 8, 65, 24, "FillR");
  UI::Button btn_circle(315, canvas_h + 8, 55, 24, "Circle");
  UI::Button btn_fillcircle(375, canvas_h + 8, 65, 24, "FillC");
  UI::Button btn_bucket(445, canvas_h + 8, 65, 24, "Bucket");
  UI::Button btn_drop(515, canvas_h + 8, 65, 24, "Drop");

  // Action buttons & Sliders (Row 2: y = canvas_h + 42)
  UI::Button btn_save(10, canvas_h + 42, 55, 24, "Save");
  UI::Button btn_open(70, canvas_h + 42, 55, 24, "Open");
  UI::Button btn_quit(130, canvas_h + 42, 50, 24, "Quit",
                                    0xFFF38BA8, 0xFF1E1E2E, 0);

  UI::Label lbl_brush(190, canvas_h + 48, "Size:");
  UI::Slider slider_brush(230, canvas_h + 46, 80, 20, 1, 20, 2);

  // RGB Sliders
  UI::Label lbl_r(325, canvas_h + 48, "R:");
  UI::Slider slider_r(340, canvas_h + 46, 110, 20, 0, 255, 0);

  UI::Label lbl_g(460, canvas_h + 48, "G:");
  UI::Slider slider_g(475, canvas_h + 46, 110, 20, 0, 255, 0);

  UI::Label lbl_b(595, canvas_h + 48, "B:");
  UI::Slider slider_b(610, canvas_h + 46, 110, 20, 0, 255, 0);

  // Status Bar
  UI::StatusBar status_bar(10, canvas_h + 82, sw - 20, 28,
                                         status_msg);
  UI::WidgetGroup panel_widgets;
  panel_widgets.add(btn_pencil);
  panel_widgets.add(btn_eraser);
  panel_widgets.add(btn_line);
  panel_widgets.add(btn_rect);
  panel_widgets.add(btn_fillrect);
  panel_widgets.add(btn_circle);
  panel_widgets.add(btn_fillcircle);
  panel_widgets.add(btn_bucket);
  panel_widgets.add(btn_drop);
  panel_widgets.add(btn_save);
  panel_widgets.add(btn_open);
  panel_widgets.add(btn_quit);
  panel_widgets.add(lbl_brush);
  panel_widgets.add(slider_brush);
  panel_widgets.add(lbl_r);
  panel_widgets.add(slider_r);
  panel_widgets.add(lbl_g);
  panel_widgets.add(slider_g);
  panel_widgets.add(lbl_b);
  panel_widgets.add(slider_b);
  panel_widgets.add(status_bar);

  bool panel_redraw_needed = true;
  bool old_left = false;
  bool running = true;

  // Track previous mouse position to detect movement
  int prev_mx = -1;
  int prev_my = -1;

  while (running && !Kernel::Scheduler::should_stop()) {
    int mx = UI::mouse_x();
    int my = UI::mouse_y();

    // Force a redraw when the mouse moves
    if (mx != prev_mx || my != prev_my) {
      panel_redraw_needed = true;
      prev_mx = mx;
      prev_my = my;
    }

    bool m_left = UI::primary_pressed();
    bool m_released = old_left && !m_left;
    UI::Widget *active_widget =
      panel_widgets.handle_mouse(mx, my, m_left, m_released);

    // Update RGB and brush size from sliders
    cur_r = slider_r.get_value();
    cur_g = slider_g.get_value();
    cur_b = slider_b.get_value();
    int brush_width = slider_brush.get_value();

    if (my < static_cast<int>(canvas_h)) {
      // --- Canvas Interaction ---
      if (m_left) {
        if (!mouse_down_prev) {
          start_x = mx;
          start_y = my;
          dragging = true;
          memcpy(backup_canvas, canvas, canvas_w * canvas_h * sizeof(uint32_t));

          if (current_tool == Tool::FloodFill) {
            flood_fill(canvas, canvas_w, canvas_h, mx, my,
                       0xFF000000 | (static_cast<uint32_t>(cur_r) << 16) |
                           (static_cast<uint32_t>(cur_g) << 8) |
                           static_cast<uint32_t>(cur_b));
            memcpy(backup_canvas, canvas,
                   canvas_w * canvas_h * sizeof(uint32_t));
            strcpy(status_msg, "Filled area.");
            status_bar.set_status(status_msg);
            dragging = false;
            panel_redraw_needed = true;
          } else if (current_tool == Tool::Eyedropper) {
            uint32_t col = canvas[my * canvas_w + mx];
            slider_r.set_value((col >> 16) & 0xFF);
            slider_g.set_value((col >> 8) & 0xFF);
            slider_b.set_value(col & 0xFF);
            strcpy(status_msg, "Picked color from canvas!");
            status_bar.set_status(status_msg);
            dragging = false;
            panel_redraw_needed = true;
          }
        } else {
          uint32_t col = 0xFF000000 | (static_cast<uint32_t>(cur_r) << 16) |
                         (static_cast<uint32_t>(cur_g) << 8) |
                         static_cast<uint32_t>(cur_b);
          if (current_tool == Tool::Pencil) {
            draw_line_pixels(canvas, canvas_w, canvas_h, start_x, start_y, mx,
                             my, col, brush_width);
            start_x = mx;
            start_y = my;
            memcpy(backup_canvas, canvas,
                   canvas_w * canvas_h * sizeof(uint32_t));
          } else if (current_tool == Tool::Eraser) {
            draw_line_pixels(canvas, canvas_w, canvas_h, start_x, start_y, mx,
                             my, COLOR_CANVAS, brush_width * 2);
            start_x = mx;
            start_y = my;
            memcpy(backup_canvas, canvas,
                   canvas_w * canvas_h * sizeof(uint32_t));
          } else if (current_tool == Tool::Line || current_tool == Tool::Rect ||
                     current_tool == Tool::FillRect ||
                     current_tool == Tool::Circle ||
                     current_tool == Tool::FillCircle) {
            memcpy(canvas, backup_canvas,
                   canvas_w * canvas_h * sizeof(uint32_t));
            if (current_tool == Tool::Line) {
              draw_line_pixels(canvas, canvas_w, canvas_h, start_x, start_y, mx,
                               my, col, brush_width);
            } else if (current_tool == Tool::Rect) {
              draw_rect_pixels(canvas, canvas_w, canvas_h, start_x, start_y, mx,
                               my, col, false, brush_width);
            } else if (current_tool == Tool::FillRect) {
              draw_rect_pixels(canvas, canvas_w, canvas_h, start_x, start_y, mx,
                               my, col, true, brush_width);
            } else if (current_tool == Tool::Circle) {
              int r = __builtin_abs(mx - start_x);
              draw_circle_pixels(canvas, canvas_w, canvas_h, start_x, start_y,
                                 r, col, false, brush_width);
            } else if (current_tool == Tool::FillCircle) {
              int r = __builtin_abs(mx - start_x);
              draw_circle_pixels(canvas, canvas_w, canvas_h, start_x, start_y,
                                 r, col, true, brush_width);
            }
          }
        }
      } else {
        if (mouse_down_prev && dragging) {
          dragging = false;
          memcpy(backup_canvas, canvas, canvas_w * canvas_h * sizeof(uint32_t));
          strcpy(status_msg, "Shape applied.");
          status_bar.set_status(status_msg);
          panel_redraw_needed = true;
        }
      }
    } else {
      // --- UI Panel Interaction ---
      if (active_widget == &btn_pencil) {
        current_tool = Tool::Pencil;
        strcpy(status_msg, "Tool: Pencil");
        status_bar.set_status(status_msg);
        panel_redraw_needed = true;
      }
      else if (active_widget == &btn_eraser) {
        current_tool = Tool::Eraser;
        strcpy(status_msg, "Tool: Eraser");
        status_bar.set_status(status_msg);
        panel_redraw_needed = true;
      }
      else if (active_widget == &btn_line) {
        current_tool = Tool::Line;
        strcpy(status_msg, "Tool: Line");
        status_bar.set_status(status_msg);
        panel_redraw_needed = true;
      }
      else if (active_widget == &btn_rect) {
        current_tool = Tool::Rect;
        strcpy(status_msg, "Tool: Rectangle");
        status_bar.set_status(status_msg);
        panel_redraw_needed = true;
      }
      else if (active_widget == &btn_fillrect) {
        current_tool = Tool::FillRect;
        strcpy(status_msg, "Tool: Filled Rectangle");
        status_bar.set_status(status_msg);
        panel_redraw_needed = true;
      }
      else if (active_widget == &btn_circle) {
        current_tool = Tool::Circle;
        strcpy(status_msg, "Tool: Circle");
        status_bar.set_status(status_msg);
        panel_redraw_needed = true;
      }
      else if (active_widget == &btn_fillcircle) {
        current_tool = Tool::FillCircle;
        strcpy(status_msg, "Tool: Filled Circle");
        status_bar.set_status(status_msg);
        panel_redraw_needed = true;
      }
      else if (active_widget == &btn_bucket) {
        current_tool = Tool::FloodFill;
        strcpy(status_msg, "Tool: Flood Fill Bucket");
        status_bar.set_status(status_msg);
        panel_redraw_needed = true;
      }
      else if (active_widget == &btn_drop) {
        current_tool = Tool::Eyedropper;
        strcpy(status_msg, "Tool: Eyedropper");
        status_bar.set_status(status_msg);
        panel_redraw_needed = true;
      }

      else if (active_widget == &btn_save) {
        char filename[64] = "drawing.png";
        if (UI::prompt_filename(win, "Save filename:", filename,
                                              sizeof(filename))) {
          save_png(filename, canvas, canvas_w, canvas_h);
          strcpy(status_msg, "File saved successfully.");
          status_bar.set_status(status_msg);
        }
        panel_redraw_needed = true;
      }

      else if (active_widget == &btn_open) {
        char filename[64] = "drawing.png";
        if (UI::prompt_filename(win, "Open filename:", filename,
                                              sizeof(filename))) {
          if (load_png(filename, canvas, canvas_w, canvas_h)) {
            memcpy(backup_canvas, canvas,
                   canvas_w * canvas_h * sizeof(uint32_t));
            strcpy(status_msg, "File loaded successfully.");
          } else {
            strcpy(status_msg, "Error loading file.");
          }
          status_bar.set_status(status_msg);
        }
        panel_redraw_needed = true;
      }

      else if (active_widget == &btn_quit) {
        running = false;
      }
      if (active_widget == &slider_brush || active_widget == &slider_r ||
          active_widget == &slider_g || active_widget == &slider_b)
        panel_redraw_needed = true;
    }

    mouse_down_prev = m_left;
    old_left = m_left;

    // Check if any widget needs dirty redraw
    if (btn_pencil.is_dirty() || btn_eraser.is_dirty() || btn_line.is_dirty() ||
        btn_rect.is_dirty() || btn_fillrect.is_dirty() ||
        btn_circle.is_dirty() || btn_fillcircle.is_dirty() ||
        btn_bucket.is_dirty() || btn_drop.is_dirty() || btn_save.is_dirty() ||
        btn_open.is_dirty() || btn_quit.is_dirty() || slider_brush.is_dirty() ||
        slider_r.is_dirty() || slider_g.is_dirty() || slider_b.is_dirty() ||
        status_bar.is_dirty() || panel_redraw_needed) {

      // Render Canvas
      win.clear(COLOR_BG);
      win.blit(canvas, 0, 0, canvas_w, canvas_h, canvas_w * sizeof(uint32_t));

      // Render Control Panel Background
      win.fill_rect(0, canvas_h, sw, 120, 0xFF313244);
      win.draw_rect(0, canvas_h, sw, 120, 0xFF45475A);

      panel_widgets.draw(win, false);

      // Draw Color Preview Box
      uint32_t preview_col = 0xFF000000 | (static_cast<uint32_t>(cur_r) << 16) |
                             (static_cast<uint32_t>(cur_g) << 8) |
                             static_cast<uint32_t>(cur_b);
      win.fill_rect(830, canvas_h + 44, 45, 22, preview_col);
      win.draw_rect(830, canvas_h + 44, 45, 22, COLOR_TEXT);

      win.flush();
      panel_redraw_needed = false;
    } else {
      Kernel::Scheduler::thread_sleep_ms(5);
    }
  }

  free(canvas);
  free(backup_canvas);
}

} // namespace Kernel::Apps::Pain