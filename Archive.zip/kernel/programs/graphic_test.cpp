#include <cstdint>
#include <oslib/keyboard.h>
#include <kernel/graphics/open_font.h>
#include <oslib/win.h>
#include <oslib/ui.h>
#include <kernel/lib/appcommon.h>
#include <kernel/scheduler.h>

namespace Kernel::Apps {
namespace {
using namespace Kernel::AppCommon;
using oslib::Keyboard;

constexpr uint32_t BG = 0x1B1111;
constexpr uint32_t FG = 0xF4D6CD;
constexpr uint32_t BLUE = 0xFAB489;
constexpr uint32_t GREEN = 0xA1E3A6;
constexpr uint32_t RED = 0xA88BF3;
constexpr uint32_t YELLOW = 0xAFE2F9;
constexpr uint32_t ORANGE = 0xF3B089;
constexpr uint32_t PURPLE = 0xD489FA;

void run_graphic_test() {
  oslib::Win win;
  if (!win.open(800, 600, 200, 150))
    return;
  const int32_t w = static_cast<int32_t>(win.width());
  const int32_t h = static_cast<int32_t>(win.height());

  int page = 0;
  int max_pages = 4;
  bool running = true;
  uint32_t anim_counter = 0;
  Kernel::Graphics::TrueTypeFont ui_font;
  const bool ui_font_loaded = Kernel::Graphics::OpenFont::load_first_available(ui_font, nullptr, 0);

  while (running && !Kernel::Scheduler::should_stop()) {
    while (Keyboard::available()) {
      char c = Keyboard::getchar();
      if (c >= 'A' && c <= 'Z')
        c += 'a' - 'A';
      if (c == 'q' || c == 27) {
        running = false;
        break;
      }
      if (c == ' ' || c == '\n' || c == '\r') {
        page = (page + 1) % max_pages;
      }
    }
    if (!running)
      break;

    win.clear(BG);

    if (ui_font_loaded) {
      UI::text(win, 20, 15, 16.0f, ui_font,
                            "GRAPHIC TEST SUITE - DIVERSE MODULES", BLUE);
      UI::text(win, 20, h - 25, 13.0f, ui_font,
                            "SPACE: NEXT PAGE    Q: QUIT", FG);
      UI::text(win, w - 60, 15, 16.0f, ui_font,
                            "1", GREEN);
      UI::text(win, w - 40, 15, 16.0f, ui_font,
                            "/4", FG);
    } else {
      UI::text(win, 20, 15, "GRAPHIC TEST SUITE - DIVERSE MODULES", BLUE);
      UI::text(win, 20, h - 25, "SPACE: NEXT PAGE    Q: QUIT", FG);
      UI::number(win, w - 60, 15, page + 1, GREEN);
      UI::text(win, w - 40, 15, "/4", FG);
    }

    if (page == 0) {
      UI::text(win, 20, 45, "1. Basic Lines, Rectangles & Triangles", YELLOW);

      win.draw_line(50, 80, 160, 130, GREEN);
      win.draw_line(160, 80, 50, 130, RED);

      win.fill_rect(190, 75, 90, 55, BLUE);
      win.fill_rect_alpha(210, 95, 90, 55, GREEN, 140);

      win.draw_circle(360, 100, 32, YELLOW);
      win.fill_circle(450, 100, 28, RED);

      win.draw_triangle(520, 130, 570, 70, 620, 130, BLUE);
      win.fill_triangle(650, 130, 700, 70, 750, 130, PURPLE);

      int32_t cx = 100 + static_cast<int32_t>(anim_counter %
                                              static_cast<uint32_t>(w - 200));
      win.fill_circle_alpha(cx, 210, 22, ORANGE, 200);
      UI::text(win, 20, 250, "Dynamic element traversal and alpha layers active.",
           FG);

    } else if (page == 1) {
      UI::text(win, 20, 45, "2. Angular Geometry, Arcs & Sectors", YELLOW);

      int32_t xc = 110, yc = 120, r = 45;
      win.draw_arc(xc, yc, r, 0, 270, GREEN);
      UI::text(win, 70, 180, "Arc", FG);

      int32_t xc2 = 250, yc2 = 120;
      int32_t dynamic_angle = static_cast<int32_t>((anim_counter * 4) % 360);
      win.draw_semicircle(xc2, yc2, r, dynamic_angle, BLUE);
      UI::text(win, 200, 180, "Semicircle", FG);

      int32_t xc3 = 390, yc3 = 120;
      win.fill_sector(xc3, yc3, r, 15, 150, RED);
      UI::text(win, 350, 180, "Sector", FG);

      int32_t xc4 = 530, yc4 = 120;
      win.fill_sector(xc4, yc4, r, 180, 310, PURPLE);
      UI::text(win, 480, 180, "Pie Wedge", FG);

      int32_t xc5 = 670, yc5 = 120;
      win.fill_circle_alpha(xc5, yc5, r, YELLOW, 110);
      UI::text(win, 610, 180, "Alpha Ring", FG);

    } else if (page == 2) {
      UI::text(win, 20, 45, "3. Rounded Rectangles & UI Paneling", YELLOW);

      win.draw_rounded_rect(50, 80, 150, 65, 10, GREEN);
      UI::text(win, 65, 105, "Outline Widget", FG);

      win.fill_rounded_rect(220, 80, 150, 65, 14, BLUE);
      UI::text(win, 245, 105, "Solid Button", BG);

      win.fill_rounded_rect(390, 80, 180, 65, 20, RED);
      UI::text(win, 420, 105, "Container Panel", FG);

      win.draw_rounded_rect(590, 80, 160, 65, 25, PURPLE);
      UI::text(win, 615, 105, "Pill Badge", YELLOW);

      UI::text(win, 20, 190,
           "Advanced UI bounding boxes and corner radii rendered cleanly.",
           GREEN);

    } else if (page == 3) {
      UI::text(win, 20, 45, "4. Multi-Layer Blending & Matrix Composition", YELLOW);

      for (int i = 0; i < 6; ++i) {
        int32_t px = 100 + i * 95;
        int32_t py = 110 + (i % 2) * 25;
        uint32_t col = (i % 2 == 0) ? GREEN : ORANGE;
        uint8_t alpha = static_cast<uint8_t>(60 + i * 30);
        win.fill_circle_alpha(px, py, 35, col, alpha);
        win.fill_rounded_rect(px - 20, py - 10, 40, 20, 6, PURPLE);
      }

      UI::text(win, 20, 210,
           "Stress testing composition blending rules across layers.", FG);
    }

    win.flush();
    anim_counter++;
    delay(2);
  }
}
} // namespace

void graphic_test_run() { run_graphic_test(); }
} // namespace Kernel::Apps
