#include <kernel/cpu.h>
#include <kernel/drivers/keyboard.h>
#include <kernel/graphics/lwm.h>
#include <kernel/init.h>
#include <kernel/scheduler.h>
#include <kernel/spinlock.h>

namespace Kernel::Drivers {

namespace {

Spinlock keyboard_lock;

bool left_shift_pressed = false;
bool right_shift_flag = false;
bool left_ctrl_pressed = false;
bool right_ctrl_flag = false;
bool left_alt_pressed = false;
bool right_alt_flag = false;
uint8_t pause_bytes_remaining = 0;

bool keyboard_focus_allows_input(uint64_t input_owner_thread_id) {
  if (!input_owner_thread_id)
    return false;
  return !Kernel::Graphics::WindowManager::has_window(input_owner_thread_id) ||
         Kernel::Graphics::WindowManager::has_keyboard_focus(input_owner_thread_id);
}

bool keyboard_focus_allows_input() {
  return keyboard_focus_allows_input(Kernel::Scheduler::current_thread_id());
}

} // namespace

bool Keyboard::rx_buffer_empty() {
  SpinlockGuard guard(keyboard_lock);
  const uint64_t thread_id = Kernel::Scheduler::current_thread_id();
  return rx_buffer_owner != thread_id || rx_buffer.empty();
}

Keyboard::RingBuffer Keyboard::rx_buffer = {{0}, 0, 0};
uint64_t Keyboard::rx_buffer_owner = 0;

bool Keyboard::shift_pressed = false;
bool Keyboard::right_shift_pressed = false;
bool Keyboard::ctrl_pressed = false;
bool Keyboard::right_ctrl_pressed = false;
bool Keyboard::alt_pressed = false;
bool Keyboard::right_alt_pressed = false;
bool Keyboard::caps_lock_active = false;
bool Keyboard::num_lock_active = true;
bool Keyboard::scroll_lock_active = false;
bool Keyboard::extended_code = false;
bool Keyboard::pause_state = false;

bool Keyboard::key_states[128] = {false};
bool Keyboard::extended_key_states[128] = {false};

const char kbd_US[128] = {
    0,    27,   '1', '2', '3', '4', '5', '6', '7', '8', '9', '0', '-',  '=',
    '\b', '\t', 'q', 'w', 'e', 'r', 't', 'y', 'u', 'i', 'o', 'p', '[',  ']',
    '\n', 0,    'a', 's', 'd', 'f', 'g', 'h', 'j', 'k', 'l', ';', '\'', '`',
    0,    '\\', 'z', 'x', 'c', 'v', 'b', 'n', 'm', ',', '.', '/', 0,    '*',
    0,    ' ',  0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,    0,
    0,    0,    '-', 0,   0,   0,   '+', 0,   0,   0,   0,   0,   0,    0,
    0,    0,    0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,    0,
    0,    0,    0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,    0,
    0,    0,    0,   0,   0,   0,   0,   0};

// Standard US Layout (Set 1) - Shifted
const char kbd_US_sft[128] = {
    0,    27,   '!', '@', '#', '$', '%', '^', '&', '*', '(', ')', '_', '+',
    '\b', '\t', 'Q', 'W', 'E', 'R', 'T', 'Y', 'U', 'I', 'O', 'P', '{', '}',
    '\n', 0,    'A', 'S', 'D', 'F', 'G', 'H', 'J', 'K', 'L', ':', '"', '~',
    0,    '|',  'Z', 'X', 'C', 'V', 'B', 'N', 'M', '<', '>', '?', 0,   '*',
    0,    ' ',  0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
    0,    0,    '-', 0,   0,   0,   '+', 0,   0,   0,   0,   0,   0,   0,
    0,    0,    0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
    0,    0,    0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
    0,    0,    0,   0,   0,   0,   0,   0};

// Extended Scancode Map (E0 prefixed keys) -> ASCII or Special mapping codes
const char kbd_US_extended[128] = {
    0, 0, 0, 0, 0, 0, 0,    0, 0, 0,   0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, '\n', 0, 0, 0,   0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0,    0, 0, '/', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0,    0, 0, 0,   0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0,    0, 0, 0,   0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0,    0, 0, 0,   0, 0, 0, 0, 0, 0, 0, 0};

// Special scancodes (Set 1)
constexpr uint8_t SCANCODE_LSHIFT = 0x2A;
constexpr uint8_t SCANCODE_RSHIFT = 0x36;
constexpr uint8_t SCANCODE_LCTRL = 0x1D;
constexpr uint8_t SCANCODE_LALT = 0x38;
constexpr uint8_t SCANCODE_CAPSLOCK = 0x3A;
constexpr uint8_t SCANCODE_NUMLOCK = 0x45;
constexpr uint8_t SCANCODE_SCROLLLOCK = 0x46;
constexpr uint8_t SCANCODE_EXTENDED = 0xE0;
constexpr uint8_t SCANCODE_PAUSE1 = 0xE1;

void __init Keyboard::init() {
  for (int i = 0; i < 10000; ++i) {
    if (!(inb(0x64) & 0x01))
      break;
    inb(0x60);
  }

  int timeout = 100000;
  while ((inb(0x64) & 0x02) && --timeout)
    ;
  if (!timeout)
    return;

  outb(0x64, 0x20);

  timeout = 100000;
  while (!(inb(0x64) & 0x01) && --timeout)
    ;
  if (!timeout)
    return;

  uint8_t command = inb(0x60);
  command |= 0x01;  // Enable first-port IRQ.
  command &= ~0x10; // Enable first-port clock.
  command |= 0x40;  // Enable first-port translation (Scancode Set 1).

  timeout = 100000;
  while ((inb(0x64) & 0x02) && --timeout)
    ;
  if (!timeout)
    return;

  outb(0x64, 0x60);

  timeout = 100000;
  while ((inb(0x64) & 0x02) && --timeout)
    ;
  if (!timeout)
    return;

  outb(0x60, command);

  // Enable First PS/2 Port (0xAE)
  timeout = 100000;
  while ((inb(0x64) & 0x02) && --timeout)
    ;
  outb(0x64, 0xAE);

  // Enable Keyboard Scanning (0xF4)
  timeout = 100000;
  while ((inb(0x64) & 0x02) && --timeout)
    ;
  outb(0x60, 0xF4);

  // Wait for ACK (0xFA)
  timeout = 100000;
  while (!(inb(0x64) & 0x01) && --timeout)
    ;
  if (timeout)
    inb(0x60);

  // Synchronize Lock LEDs
  update_leds();

  // Unmask IRQ1 on the master PIC.
  uint8_t mask = inb(0x21);
  outb(0x21, mask & ~0x02);
}

bool Keyboard::available() {
  return available_for(Kernel::Scheduler::current_thread_id());
}

bool Keyboard::available_for(uint64_t input_owner_thread_id) {
  if (!keyboard_focus_allows_input(input_owner_thread_id))
    return false;
  SpinlockGuard guard(keyboard_lock);
  return rx_buffer_owner == input_owner_thread_id && !rx_buffer.empty();
}

bool Keyboard::try_getchar_for(uint64_t input_owner_thread_id, char *out) {
  if (!out || !keyboard_focus_allows_input(input_owner_thread_id))
    return false;
  SpinlockGuard guard(keyboard_lock);
  if (rx_buffer_owner != input_owner_thread_id || rx_buffer.empty())
    return false;
  *out = rx_buffer.pop();
  return true;
}

char Keyboard::getchar() {
  const uint64_t input_owner_thread_id =
      Kernel::Scheduler::current_thread_id();
  for (;;) {
    if (!keyboard_focus_allows_input(input_owner_thread_id)) {
      Kernel::Scheduler::thread_sleep_ms(4);
      continue;
    }
    if (!Kernel::Scheduler::thread_block_if(rx_buffer_empty)) {
      char value = 0;
      if (try_getchar_for(input_owner_thread_id, &value))
        return value;
    }
  }
}

void Keyboard::handle_interrupt() {
  const uint64_t input_owner =
      Kernel::Graphics::WindowManager::keyboard_focus_thread_id();
  bool wake_waiters = false;

  {
    SpinlockGuard guard(keyboard_lock);
    const uint8_t status = inb(0x64);
    if (!(status & 0x01) || (status & 0x20)) {
      return;
    }

    const uint8_t scancode = inb(0x60);
    if (scancode == 0xFA || scancode == 0xFE) {
      return;
    }

    if (rx_buffer_owner != input_owner) {
      rx_buffer.clear();
      rx_buffer_owner = input_owner;
    }

    // Consume the remaining 5 bytes of the 6-byte PS/2 Pause sequence
    // (E1 1D 45 E1 9D C5) so it does not leak into NumLock or key states.
    if (pause_bytes_remaining > 0) {
      --pause_bytes_remaining;
      pause_state = (pause_bytes_remaining > 0);
      return;
    }

    if (scancode == SCANCODE_PAUSE1) {
      pause_bytes_remaining = 5;
      pause_state = true;
      extended_code = false;
      return;
    }

    if (scancode == SCANCODE_EXTENDED) {
      extended_code = true;
      return;
    }

    const bool was_extended = extended_code;
    extended_code = false;

    const bool is_release = (scancode & 0x80) != 0;
    const uint8_t base_scancode = scancode & 0x7F;
    const bool pressed = !is_release;

    if (base_scancode < 128) {
      if (was_extended) {
        extended_key_states[base_scancode] = pressed;
      } else {
        key_states[base_scancode] = pressed;
      }
    }

    auto sync_modifiers = [&]() {
      shift_pressed = left_shift_pressed || right_shift_flag;
      right_shift_pressed = right_shift_flag;
      ctrl_pressed = left_ctrl_pressed || right_ctrl_flag;
      right_ctrl_pressed = right_ctrl_flag;
      alt_pressed = left_alt_pressed || right_alt_flag;
      right_alt_pressed = right_alt_flag;
    };

    if (was_extended) {
      if (base_scancode == 0x1D) {
        right_ctrl_flag = pressed;
        sync_modifiers();
        return;
      }
      if (base_scancode == 0x38) {
        right_alt_flag = pressed;
        sync_modifiers();
        return;
      }
    } else {
      if (base_scancode == SCANCODE_LSHIFT) {
        left_shift_pressed = pressed;
        sync_modifiers();
        return;
      }
      if (base_scancode == SCANCODE_RSHIFT) {
        right_shift_flag = pressed;
        sync_modifiers();
        return;
      }
      if (base_scancode == SCANCODE_LCTRL) {
        left_ctrl_pressed = pressed;
        sync_modifiers();
        return;
      }
      if (base_scancode == SCANCODE_LALT) {
        left_alt_pressed = pressed;
        sync_modifiers();
        return;
      }
      if (!is_release) {
        if (base_scancode == SCANCODE_CAPSLOCK) {
          caps_lock_active = !caps_lock_active;
          update_leds();
          return;
        }
        if (base_scancode == SCANCODE_NUMLOCK) {
          num_lock_active = !num_lock_active;
          update_leds();
          return;
        }
        if (base_scancode == SCANCODE_SCROLLLOCK) {
          scroll_lock_active = !scroll_lock_active;
          update_leds();
          return;
        }
      }
    }

    if (is_release) {
      return;
    }

    if (base_scancode < 128) {
      char ascii = 0;

      if (was_extended) {
        ascii = kbd_US_extended[base_scancode];
      } else {
        bool use_shift = shift_pressed;
        const char normal_char = kbd_US[base_scancode];

        if (caps_lock_active && normal_char >= 'a' && normal_char <= 'z') {
          use_shift = !use_shift;
        }

        ascii = use_shift ? kbd_US_sft[base_scancode] : normal_char;
      }

      if (ascii != 0) {
        rx_buffer.push(ascii);
        wake_waiters = true;
      }
    }
  }

  if (wake_waiters)
    Kernel::Scheduler::unblock_io_threads();
}

bool Keyboard::is_pressed(uint8_t scancode) {
  if (scancode >= 128)
    return false;
  if (!keyboard_focus_allows_input())
    return false;
  SpinlockGuard guard(keyboard_lock);
  return key_states[scancode];
}

bool Keyboard::is_extended_pressed(uint8_t scancode) {
  if (scancode >= 128)
    return false;
  if (!keyboard_focus_allows_input())
    return false;
  SpinlockGuard guard(keyboard_lock);
  return extended_key_states[scancode];
}

bool Keyboard::is_shift_pressed() {
  SpinlockGuard guard(keyboard_lock);
  return shift_pressed;
}

bool Keyboard::is_ctrl_pressed() {
  SpinlockGuard guard(keyboard_lock);
  return ctrl_pressed;
}

bool Keyboard::is_alt_pressed() {
  SpinlockGuard guard(keyboard_lock);
  return alt_pressed;
}

bool Keyboard::is_caps_lock_active() {
  SpinlockGuard guard(keyboard_lock);
  return caps_lock_active;
}

bool Keyboard::is_num_lock_active() {
  SpinlockGuard guard(keyboard_lock);
  return num_lock_active;
}

bool Keyboard::is_scroll_lock_active() {
  SpinlockGuard guard(keyboard_lock);
  return scroll_lock_active;
}

void Keyboard::update_leds() {
  uint8_t leds = 0;
  if (caps_lock_active)
    leds |= (1 << 2);
  if (num_lock_active)
    leds |= (1 << 1);
  if (scroll_lock_active)
    leds |= (1 << 0);

  int timeout = 100000;
  while ((inb(0x64) & 0x02) && --timeout)
    ;
  if (!timeout)
    return;

  outb(0x60, 0xED);

  timeout = 100000;
  while (!(inb(0x64) & 0x01) && --timeout)
    ;
  if (timeout)
    inb(0x60);

  timeout = 100000;
  while ((inb(0x64) & 0x02) && --timeout)
    ;
  if (!timeout)
    return;

  outb(0x60, leds);

  timeout = 100000;
  while (!(inb(0x64) & 0x01) && --timeout)
    ;
  if (timeout)
    inb(0x60);
}

} // namespace Kernel::Drivers
