# OSFOS process, thread, shell, and stdio update

This change introduces a small in-kernel process model around the existing scheduler. Programs remain statically linked kernel code; this is not an ELF userspace loader or a ring-3 isolation layer.

## Execution model

- The scheduler has a permanent kernel process. Its bootstrap thread and kernel-created service threads belong to that process.
- `thread_create()` creates another thread in the caller's process. Threads share the process heap, arguments, terminal association, and stdio context.
- `process_spawn()` creates a child process with a main thread. It copies `argv` into kernel-owned process metadata, records the parent/child relationship, and inherits the parent's terminal thread ID.
- `process_wait(pid, &status)` accepts a direct child PID and blocks the caller until that child becomes a zombie. The child's exit status is then returned through `status`, and its PCB/argument block is reaped.
- `process_exit(status)` requests shutdown of the process's other threads, wakes scheduler-blocked siblings, and only publishes process exit after the last member thread exits. A process therefore outlives its main thread while any worker thread remains. CPU-bound workers must cooperate by checking `should_stop()` or reaching a yield/block cancellation point; the scheduler does not forcibly preempt a thread into safe termination.
- `auto_reap=true` is intended only for detached children such as the shell process started by the kernel. Use the default `false` for a child that must be waited on.
- When a parent exits, its remaining children are reparented to the kernel process. Detached orphans are reaped when they finish.

`thread_create()` does not implicitly create a window. Window registration is a separate operation performed by graphical applications. CLI applications therefore run as processes without acquiring a GUI window.

## Allocation lifetime

- `malloc()`, `calloc()`, `realloc()`, and C++ allocations use process ownership inside an application process. Memory is shared by all threads in that process and is reclaimed when the final process thread exits.
- `thread_malloc()` explicitly creates a thread-lifetime allocation. It is reclaimed when that particular thread exits.
- In the permanent kernel process, ordinary `malloc()` remains thread-owned by default. Long-lived shared kernel objects should use an explicit kernel ownership policy rather than relying on a short-lived worker's allocation lifetime.
- Scheduler TCBs, stacks, copied process arguments, and PCBs are allocated with explicit owner `0` and manually released by scheduler lifecycle code. They cannot accidentally be swept when the creating thread exits.
- Process and thread IDs are kept within 31 bits because the slab allocator reserves an ownership-tag bit to distinguish process-owned blocks from thread-owned blocks. New creation fails cleanly at that limit rather than allowing ownership-tag collisions.

The heap exposes `get_thread_allocated_size()` and `get_process_allocated_size()` for diagnostics. The CLI `memlife` command exercises both ownership classes and verifies worker-thread reclamation.

## stdio and file ownership

Every process lazily receives its own `StdioContext`, standard stream objects, descriptor counter, and open-file list. `stdin`, `stdout`, and `stderr` are process-resolved macros backed by `__os_stdin()`, `__os_stdout()`, and `__os_stderr()`.

A child process receives a fresh stdio context. Its standard streams route through the inherited terminal thread ID, so the shell can block in `process_wait()` while the child reads from and writes to the same terminal. This ID identifies the terminal/input-queue owner, not the executing child thread. The keyboard driver therefore exposes owner-aware reads (`available_for()` and `try_getchar_for()`), and never clears another thread's input merely because the current reader has a different TID. Ordinary `FILE *` handles belong to the process that opened them; cross-process use is rejected. Remaining open files are closed when the process exits. `errno` is stored per thread.

The declared API in `include/stdio.h` is implemented in `kernel/lib/compatlibc.cpp`, including formatted output/input, string formatting/scanning, character/line I/O, file open/close/read/write/seek/tell, error/EOF state, descriptors, `remove()`, and `rename()`. Decimal floating-point scanning supports `%f`/`%e`/`%g` and their uppercase forms, with `%lf` for `double`.

The current VFS-backed streams are intentionally unbuffered. `setvbuf()` accepts `_IONBF`; `_IOFBF` and `_IOLBF` return `ENOSYS` for now. The formatter provides fixed-point `%f`/`%F`; it does not yet implement every ISO C floating format such as `%e` and `%g`. This is a compact kernel compatibility layer, not a claim of full hosted-libc conformance.

## Shell behavior

The shell now runs as a child process of the kernel. Each registered application command is started as a child process of the shell, and the shell calls `process_wait()` before printing the next prompt. Nonzero exit status is reported. This is a synchronous command shell over the existing static program registry; it is not a POSIX shell and does not yet implement ELF execution, pipelines, redirection, background jobs, environment expansion, or shell scripting.

The command-line parser supports whitespace separation, single/double-quoted arguments, and backslash escaping.

## CLI regression commands

Run these from the OSFOS shell:

```text
args alpha "two words" ''
exitcode 7
stdio-test
memlife
```

- `args` prints PID, parent PID, `argc`, and each argument, including quoted/empty arguments.
- `exitcode 7` returns status 7; the shell should wait, report the status, then show another prompt.
- `stdio-test` interactively reads a word and integer, exercises `printf`/`scanf`, `fprintf`/`fwrite`, `fflush`, `fscanf`, `fread`, `fseek`, `ftell`, EOF/error state, `fclose`, `remove`, and `snprintf`.
- `memlife` checks process-owned and thread-owned allocations, then verifies the worker's thread-owned allocation disappears when that worker exits.

## Validation performed

- 54 of 55 kernel C++ translation units compiled with host `g++` in C++20 freestanding mode. The only unavailable unit was `kernel/net/http_client.cpp`, because the uploaded tree does not contain `bearssl.h`.
- 84 of 85 kernel C translation units compiled with host `gcc` in freestanding C11 mode. The only unavailable unit was `kernel/net/bearssl_trust_anchors.c`, for the same missing BearSSL headers.
- A full `make` could not reach the link stage: the archive is missing `third_party/bearssl/src` and `rust/net/src`, and `nasm` is not installed in the build environment. No boot/QEMU runtime test was possible here.
