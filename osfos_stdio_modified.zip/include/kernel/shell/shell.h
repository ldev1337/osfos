#pragma once


namespace Kernel::Shell {
void run();
int process_entry(int argc, char **argv, void *context);
}

extern "C" void kprintf(const char *fmt, ...);